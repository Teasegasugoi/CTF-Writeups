INSERT INTO todos(id,body) VALUE (1, "hoge");
INSERT INTO todos(id,body) VALUE (2, "fuga");
INSERT INTO todos(id,body) VALUE (3, "piyo");

INSERT INTO flags(body) VALUE("ctf4b{dummy flag!!!}");